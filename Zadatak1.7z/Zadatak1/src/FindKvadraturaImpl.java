import java.io.File;
import java.util.Scanner;

public class FindKvadraturaImpl extends FindKvadratura {
    public static void main(String[] args) {
        parseFile(String gradBaza, String, searchString);
        Scanner scan = new Scanner(new File(gradBaza));
        while(scan.hasNext()){
            String line = scan.nextLine().toLowerCase().toString();
            if(line.contains(searchString)){
                System.out.println(line);
            }
        }
    }
}
