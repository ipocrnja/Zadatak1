import java.io.File;
import java.util.Scanner;

public class PProstorImpl extends PProstor {
    public static void parseFile(String gradBaza, String, searchString);
        Scanner scan = new Scanner(new File(gradBaza));
        while(scan.hasNext()){
            String line = scan.nextLine().toLowerCase().toString();
            if(line.contains(searchString)){
                System.out.println(line);
            }
        }
    }
}
