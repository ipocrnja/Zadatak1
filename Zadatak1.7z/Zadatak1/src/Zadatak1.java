import javax.net.ssl.HttpsURLConnection;
//import java.net.HttpURLConnection;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.Scanner;

public class Zadatak1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print(" Enter city of interest : ");
        String gradUpit = input.nextLine();
        System.out.println(" Your input : " + gradUpit);

        URL nestoria = new URL("https://www.nestoria.de/" + gradUpit + "/property");
        HttpsURLConnection nest = nestoria.openConnection();
        System.out.println(" Checking Nestoria for data ");
        String gradBaza;
        PrintStream out = new PrintStream(new FileOutputStream(gradBaza + ".txt"));

        // nedostaju specifikacije za https - config
        // izvoz u txt file i pretrazivanje po txt i ispis kvadrature ...
        // ili ispis na ekran - dati korisniku da odabere ?
        // https jer mi ne dopusta, ne radi api ... kriva naredba ili je server down
        // pretraziti stan kuca poslovni prostor pa u svaj od tih klasa zasebno traziti
        // kvadraturu cijenu ...

        class FindStan{

        }

        class PProstor{

        }
        class FindKvadratura{

        }
        class FindCijena{

        }
    }
}
